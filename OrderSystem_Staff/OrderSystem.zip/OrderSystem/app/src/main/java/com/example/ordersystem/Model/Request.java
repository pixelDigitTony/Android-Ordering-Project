package com.example.ordersystem.Model;

import java.sql.Time;
import java.sql.Timestamp;

public class Request {
    private int requestId;
    private String requestdateTime;
    private String requestStatus;
    private String requestName;
    private String requestTotal;

    public Request(int requestId, String requestdateTime, String requestStatus, String requestName, String requestTotal) {
        this.requestId = requestId;
        this.requestdateTime = requestdateTime;
        this.requestStatus = requestStatus;
        this.requestName = requestName;
        this.requestTotal = requestTotal;
    }

    public int getRequestId() {
        return requestId;
    }

    public String getRequestdateTime() {
        return requestdateTime;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public String getRequestName() {
        return requestName;
    }

    public String getRequestTotal() {
        return requestTotal;
    }
}
